
package com.solt.samples;

public class FirstLambda {
    public static void main(String[] args) {
        
    }
}
